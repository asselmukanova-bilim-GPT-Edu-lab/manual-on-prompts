import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
const root = fileURLToPath(new URL('../', import.meta.url));
const src = resolve(root, 'dist');
const inlineAssets = text => text.replace(/assets\/[a-zA-Z0-9_.-]+/g, name => {
  const mime = name.endsWith('.svg') ? 'image/svg+xml' : 'image/png';
  return `data:${mime};base64,${readFileSync(resolve(src, name)).toString('base64')}`;
});
let html = await readFile(resolve(src, 'index.html'), 'utf8');
const css = inlineAssets(await readFile(resolve(src, 'styles.css'), 'utf8'));
html = html.replace('<link rel="stylesheet" href="styles.css">', `<style>${css}</style>`);
const scripts = [];
for (const file of ['data.js', 'prompt.js', 'app.js']) {
  html = html.replace(`<script src="${file}" defer></script>`, '');
  const js = inlineAssets(await readFile(resolve(src, file), 'utf8')).replaceAll('</script', '<\\/script');
  scripts.push(`<script>${js}</script>`);
}
html = inlineAssets(html).replace('</body>', scripts.join('\n') + '\n</body>');
await mkdir(resolve(root, 'release'), {recursive: true});
await writeFile(resolve(root, 'release/index.html'), html);
console.log('Self-contained site: release/index.html');
