import { cp, mkdir, readdir, readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import vm from 'node:vm';
const root = fileURLToPath(new URL('../', import.meta.url));
const source = resolve(root, 'src');
for (const name of ['data.js', 'prompt.js', 'app.js']) new vm.Script(await readFile(resolve(source, name), 'utf8'), { filename: name });
await mkdir(resolve(root, 'dist'), { recursive: true });
await cp(source, resolve(root, 'dist'), { recursive: true });
await writeFile(resolve(root, 'dist/.nojekyll'), '');
const assets = await readdir(resolve(source, 'assets'));
for (const file of ['index.html', 'styles.css', ...assets.map(x => `assets/${x}`)]) {
  if (!(await readFile(resolve(source, file))).length) throw new Error(`Empty file: ${file}`);
}
const hash = createHash('sha256').update(await readFile(resolve(source, 'data.js'))).digest('hex').slice(0, 12);
console.log(`Build OK: dist/ · ${assets.length} assets · content ${hash}`);
