"""Generate the printable checklist from the site's shared content (ReportLab)."""
import json
import subprocess
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from xml.sax.saxutils import escape

root = Path(__file__).resolve().parent.parent
data = json.loads(subprocess.check_output([
    'node', '-e', "const fs=require('fs'),vm=require('vm');const c={window:{}};vm.runInNewContext(fs.readFileSync('src/data.js','utf8'),c);console.log(JSON.stringify(c.window.GUIDE.checklist));"
], cwd=root, encoding='utf-8'))
fonts = Path('C:/Windows/Fonts')
pdfmetrics.registerFont(TTFont('Arial', str(fonts / 'arial.ttf')))
pdfmetrics.registerFont(TTFont('ArialBold', str(fonts / 'arialbd.ttf')))
target = root / 'src/assets/checklist.pdf'
c = canvas.Canvas(str(target), pagesize=A4)
c.setTitle('Чек-лист проверки материала перед уроком | Bilim UpSkill')
c.setAuthor('Bilim UpSkill')
w, h = A4
navy, blue, muted = map(HexColor, ['#142b60', '#2854d8', '#53627c'])
style = ParagraphStyle('body', fontName='Arial', fontSize=9.3, leading=12, textColor=muted)

def paragraph(text, x, top, width, font_size=9.3, color=muted):
    s = ParagraphStyle('line', parent=style, fontSize=font_size, leading=font_size+2.8, textColor=color)
    p = Paragraph(escape(text), s)
    _, height = p.wrap(width, 100)
    p.drawOn(c, x, top-height)
    return height

c.drawImage(str(root/'src/assets/bilim-upskill.png'), 36, h-73, width=107, height=41, mask='auto', preserveAspectRatio=True)
c.setFillColor(navy)
c.setFont('ArialBold', 20)
c.drawString(36, h-108, 'Готов ли материал к уроку?')
paragraph('Чек-лист проверки результата ИИ. Отмечайте только проверенные пункты.', 36, h-122, w-72, 10)
c.setFont('Arial', 9)
c.setFillColor(muted)
c.drawString(36, h-158, 'Материал / тема: _______________________________________  Дата: ______________')
top = h-178
row_height = 59
for i, (title, description, correction) in enumerate(data):
    y = top - i*row_height
    c.setStrokeColor(HexColor('#d6e0f5'))
    c.setFillColor(HexColor('#f6f8ff') if i%2 == 0 else HexColor('#ffffff'))
    c.roundRect(36, y-row_height+4, w-72, row_height-4, 7, fill=1, stroke=1)
    c.setStrokeColor(muted)
    c.setFillColor(HexColor('#ffffff'))
    c.rect(47, y-23, 10, 10, fill=1, stroke=1)
    c.setFillColor(navy)
    c.setFont('ArialBold', 10.5)
    c.drawString(68, y-17, title)
    paragraph(description, 68, y-24, w-116)
    paragraph('Если не выполнено: '+correction, 68, y-39, w-116, 8, muted)

paragraph('Перед применением исправьте недостатки. Окончательное решение об использовании материала и оценивании принимает педагог.', 36, 115, w-72, 9.5, navy)
c.setStrokeColor(HexColor('#d6e0f5'))
c.line(36, 64, w-36, 64)
c.setFont('Arial', 8)
c.setFillColor(muted)
c.drawString(36, 48, 'Bilim UpSkill  |  Методическое руководство по созданию промтов')
c.drawRightString(w-36, 48, '1 / 1')
c.showPage()
c.save()
print(target)
