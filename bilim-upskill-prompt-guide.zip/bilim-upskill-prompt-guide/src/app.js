(() => {
  'use strict';
  const D = window.GUIDE;
  const $ = (s, root = document) => root.querySelector(s);
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const state = { task: 'lesson', fields: { time: '45' }, result: '', dirty: false, checks: new Set() };
  let copies = [], toastTimer;
  const buttonLink = (label, href) => `<a class="button" href="${href}">${label}<span aria-hidden="true">↗</span></a>`;
  const tasks = (showArrows = true) => `<div class="task-grid">${D.tasks.map(t => `<a class="task-card" href="#/create/builder/${t.id}"><span class="task-number">${t.icon}</span><div><h3>${t.title}</h3><p>${t.short}</p></div>${showArrows ? '<span class="task-arrow" aria-hidden="true">↗</span>' : ''}</a>`).join('')}</div>`;
  const elements = () => `<ol class="elements-grid">${D.elements.map((x, i) => `<li><span class="element-number">${String(i + 1).padStart(2, '0')}</span><h3>${x[0]}</h3><p>${x[1]}</p><div class="element-example">${x[2]}</div></li>`).join('')}</ol>`;
  const steps = (items, cycle = false) => `<ol class="steps ${cycle ? 'cycle' : ''}">${items.map((x, i) => `<li><span class="step-number">${String(i + 1).padStart(2, '0')}</span><h3>${x[0]}</h3><p>${x[1]}</p></li>`).join('')}</ol>`;
  const cards = items => `<div class="content-grid">${items.map(x => `<article class="content-card"><h3>${x[0]}</h3><p>${x[1]}</p></article>`).join('')}</div>`;
  function promptBlock(text) {
    const id = copies.push(text) - 1;
    return `<div class="prompt-block"><div class="prompt-block-head"><span>ЗАПРОС ДЛЯ АДАПТАЦИИ</span><button class="small-button" data-copy="${id}">Копировать</button></div><pre tabindex="0">${esc(text)}</pre></div>`;
  }
  function renderBlock(b) {
    if (b.type === 'steps') return steps(b.items, b.cycle);
    if (b.type === 'cards') return cards(b.items);
    if (b.type === 'elements') return elements();
    if (b.type === 'prompt') return promptBlock(b.text);
    if (b.type === 'note') return `<aside class="notice"><span class="notice-icon" aria-hidden="true">i</span><div><h3>${b.title}</h3><p>${b.text}</p></div></aside>`;
    if (b.type === 'text') return `<section class="prose"><h2>${b.title}</h2><p>${b.text}</p></section>`;
    if (b.type === 'link') return `<div class="block-link">${buttonLink(b.text, b.href)}</div>`;
    if (b.type === 'compare') return `<article class="comparison"><div class="before"><span class="eyebrow">ДО</span><p>${b.before}</p></div><div class="after"><span class="eyebrow">ПОСЛЕ</span><p>${b.after}</p></div><p class="comparison-why">${b.why}</p></article>`;
    if (b.type === 'flags') return `<div class="flag-grid">${b.items.map((x, i) => `<article class="flag-card"><span class="flag-label">ПРОВЕРИТЬ · ${i + 1}</span><h3>${x[0]}</h3><p>${x[1]}</p></article>`).join('')}</div>`;
    return '';
  }
  function navigation(section) {
    $('#navigation').innerHTML = D.sections.map(s => `<a class="nav-link" href="#/${s.id}/${s.pages[0][0]}"${section === s.id ? ' aria-current="true"' : ''}>${s.title}</a>`).join('');
  }
  function home() {
    return `<section class="hero container">
      <div class="hero-copy">
        <p class="eyebrow">ПРАКТИЧЕСКИЙ ГИД ДЛЯ ПЕДАГОГА</p>
        <h1>Методическое руководство по созданию промтов</h1>
        <p class="hero-lead">Подготовьте запрос для урока, задания или обратной связи. Простые поля, готовые формулировки и проверка результата.</p>
        <div class="hero-actions">${buttonLink('Создать промпт', '#/create/builder')}</div>
      </div>
      <div class="hero-workspace"><div class="workspace-title"><span class="pill">6 сценариев</span></div><h2>Что готовим к уроку?</h2>${tasks(false)}<p class="workspace-foot">Выберите материал — откроется подходящий шаблон.</p></div>
    </section>
    <section class="container home-route"><div class="section-heading"><div><h2>От замысла до применения</h2></div></div>${steps([['Задача', 'Выберите один результат.'], ['Условия', 'Добавьте цель и контекст.'], ['Промпт', 'Скопируйте готовый запрос.'], ['Проверка', 'Сверьте ответ по критериям.'], ['Применение', 'Уточните и испытайте материал.']])}</section>
    <section class="container home-bottom"><a class="feature-card blue" href="#/learn/structure"><h2>8 элементов.<br>Одна понятная структура.</h2><p>Разберитесь, что добавить в промпт и зачем.</p><span class="text-link">Изучить формулу ↗</span></a><a class="feature-card lilac" href="#/safety/anonymize"><h2>Учебная задача —<br>без личных данных.</h2><p>Пройдите шаги обезличивания файла.</p><span class="text-link">Проверить безопасность ↗</span></a><a class="feature-card dark" href="#/check/checklist"><h2>Хороший ответ<br>нужно проверить.</h2><p>9 пунктов перед использованием в классе.</p><span class="text-link">Открыть чек-лист ↗</span></a></section>`;
  }
  function layout(section, page, body, title, lead) {
    return `<div class="page-banner"><div class="container"><div class="breadcrumbs"><a href="#/">Главная</a><span aria-hidden="true">/</span><span>${section.title}</span></div><p class="eyebrow">${section.title}</p><h1>${title}</h1><p class="page-lead">${lead}</p></div></div>
    <div class="container page-layout"><aside class="section-sidebar"><p>${section.title}</p><nav aria-label="Раздел ${section.title}">${section.pages.map(p => `<a ${page === p[0] ? 'aria-current="page"' : ''} href="#/${section.id}/${p[0]}">${p[1]}<span aria-hidden="true">${page === p[0] ? '→' : ''}</span></a>`).join('')}</nav><div class="sidebar-tip">${section.intro}</div></aside><div class="page-content">${body}</div></div>`;
  }
  function field(id, title, placeholder, opts = {}) {
    const { required = false, textarea = false, type = 'text', help = '', wide = false } = opts;
    let control;
    if (id === 'grade') control = `<select id="${id}" name="${id}" required><option value="">Выберите класс</option>${Array.from({ length: 11 }, (_, i) => `<option value="${i + 1}" ${state.fields.grade == i + 1 ? 'selected' : ''}>${i + 1} класс</option>`).join('')}</select>`;
    else if (textarea) control = `<textarea id="${id}" name="${id}" rows="${id === 'objective' ? 3 : 2}" maxlength="6000" placeholder="${placeholder}" ${required ? 'required' : ''} ${help ? `aria-describedby="${id}-help"` : ''}>${esc(state.fields[id] || '')}</textarea>`;
    else control = `<input id="${id}" name="${id}" type="${type}" value="${esc(state.fields[id] || '')}" placeholder="${placeholder}" ${type === 'number' ? 'min="1" max="600" step="1"' : 'maxlength="300"'} ${required ? 'required' : ''} ${help ? `aria-describedby="${id}-help"` : ''}>`;
    return `<div class="field ${wide ? 'wide' : ''}"><label for="${id}">${title}${required ? '<span class="required" aria-hidden="true"> *</span>' : ''}</label>${control}${help ? `<small id="${id}-help">${help}</small>` : ''}</div>`;
  }
  function builder() {
    const task = D.tasks.find(t => t.id === state.task);
    return `<div class="builder-intro"><span class="eyebrow">ВАША ЗАДАЧА</span><h2>Соберите запрос для своего класса</h2><p>Начните с основных данных. Требования к выбранному материалу уже включены в шаблон.</p></div>
      <div class="task-selector" role="group" aria-label="Тип педагогической задачи">${D.tasks.map(t => `<button type="button" data-task="${t.id}" aria-pressed="${t.id === state.task}" class="task-choice"><span>${t.icon}</span>${t.title}</button>`).join('')}</div>
      <div class="builder-grid"><form id="prompt-form" class="builder-form"><div class="form-section"><div class="form-section-heading"><span>1</span><h3>Основа материала</h3></div><p class="form-hint">* Обязательные поля. Не вводите персональные данные.</p><div class="fields">
        ${field('subject', 'Предмет', 'Например, информатика', { required: true })}
        ${field('grade', 'Класс', '', { required: true })}
        ${field('topic', 'Тема', 'Например, условный оператор', { required: true })}
        ${field('time', 'Время, минут', '45', { required: true, type: 'number' })}
        ${field('objective', 'Точная цель обучения', 'Вставьте код и формулировку из программы', { required: true, textarea: true, wide: true, help: 'Скопируйте дословно из действующей учебной программы. Конструктор не придумывает коды целей.' })}
      </div></div>
      <div class="form-section"><div class="form-section-heading"><span>2</span><h3>Условия и источники</h3></div><div class="fields">
        ${field('context', 'Контекст класса', 'Уровень, поддержка, ресурсы, работа в парах…', { textarea: true, wide: true, help: 'Только обобщённые учебные сведения: без имён, диагнозов и идентифицирующих деталей.' })}
        ${field('sources', 'Источники', 'Программа — цель; образец — форма; работа А — ответ; критерии — проверка', { required: true, textarea: true, wide: true, help: 'Укажите название и назначение каждого источника. Файлы затем приложите в разрешённом ИИ-сервисе после проверки и обезличивания.' })}
      </div></div>
      <details class="extra-fields"><summary><span class="form-section-heading"><span>3</span><strong>Уточнить требования</strong></span><span aria-hidden="true">+</span></summary><p class="form-hint">Эти поля дополняют безопасную основу выбранного шаблона.</p><div class="fields">
        ${field('requirements', 'Требования', 'Количество заданий, поддержка, критерии…', { textarea: true, wide: true })}
        ${field('format', 'Формат результата', 'Объём, разделы, таблица, печатный лист…', { textarea: true, wide: true })}
        ${field('constraints', 'Ограничения', 'Что исключить, допустимые ресурсы…', { textarea: true, wide: true })}
        ${field('verification', 'Дополнительная проверка', 'Что особенно важно перепроверить…', { textarea: true, wide: true })}
      </div></details>
      ${['review', 'feedback'].includes(state.task) ? '<div class="notice compact"><p>Для этой задачи нужны обезличенная работа и критерии. Нечитаемые фрагменты оценивать нельзя. <a href="#/safety/anonymize">Как подготовить файл ↗</a></p></div>' : ''}
      <button class="button generate" type="submit">Собрать промпт <span aria-hidden="true">→</span></button><p class="privacy-caption">Поля обрабатываются только в браузере и очищаются при перезагрузке.</p>
      </form>
      <aside class="result-panel"><div class="result-head"><span class="eyebrow">${task.title}</span><span class="result-badge">Текст запроса</span></div><h2 id="result-title">${state.result ? 'Ваш промпт готов' : 'Здесь появится ваш промпт'}</h2>
      <p id="result-status" role="status">${state.result ? (state.dirty ? 'Поля изменены. Соберите промпт заново.' : 'Скопируйте текст в разрешённый ИИ-сервис и приложите указанные источники.') : 'Заполните поля слева и нажмите «Собрать промпт».'}</p>
      <div id="empty-result" ${state.result ? 'hidden' : ''}><div class="preview-lines" aria-hidden="true"><span></span><span></span><span></span></div><div class="included"><strong>В шаблоне уже есть</strong><ul><li>Структура выбранного материала</li><li>Требование сохранить точную цель</li><li>Защита данных и проверка источников</li><li>Финальная проверка педагогом</li></ul></div></div>
      <label class="visually-hidden" for="prompt-result">Готовый промпт</label><textarea id="prompt-result" readonly ${!state.result ? 'hidden' : ''}>${esc(state.result)}</textarea>
      <button id="copy-result" type="button" class="button copy-button" ${!state.result || state.dirty ? 'disabled' : ''}>Копировать промпт <span aria-hidden="true">⧉</span></button>
      <a class="result-next" href="#/check/checklist">После ответа ИИ: проверить результат →</a><p class="result-foot">Конструктор составляет запрос. Ответ ИИ вы получите в выбранном сервисе.</p></aside></div>`;
  }
  function checklist() {
    return `${steps([['Сверьте', 'Цель, программу, факты и источники.'], ['Решите', 'Все задания и расчёты самостоятельно.'], ['Адаптируйте', 'Язык, время, поддержку и ресурсы.'], ['Примите решение', 'Исправьте недостатки до урока.']])}<div class="check-header"><div><h2>Готов ли материал к уроку?</h2><p>Отметьте только то, что вы действительно проверили.</p></div><button class="small-button" id="reset-checks">Сбросить отметки</button></div><div class="check-progress"><div><span id="check-count">${state.checks.size} из ${D.checklist.length} проверено</span><span>Проверяет педагог</span></div><progress id="check-progress" max="${D.checklist.length}" value="${state.checks.size}" aria-label="Прогресс проверки"></progress></div><div class="checklist">${D.checklist.map((x, i) => `<div class="check-item"><label><input type="checkbox" data-check="${i}" ${state.checks.has(i) ? 'checked' : ''}><span><strong>${x[0]}</strong><span>${x[1]}</span></span></label><details><summary>Если не выполнено</summary><p>${x[2]}</p></details></div>`).join('')}</div><p class="check-conclusion notice" id="check-conclusion" role="status">${checkConclusion()}</p>`;
  }
  function checkConclusion() { return state.checks.size === D.checklist.length ? 'Все пункты отмечены. Окончательное решение об использовании материала остаётся за вами.' : 'Вернитесь к непроверенным пунктам. Отметки в чек-листе — ваша самооценка, а не автоматическая экспертиза.'; }
  function laws(type) {
    return `${renderBlock({ type: 'note', title: 'Справочная информация, а не правовое заключение', text: 'Реквизиты взяты из руководства. Перед использованием сверяйте действующую редакцию, приложение и применимость нормы. Практические правила ниже — методические рекомендации; они не заменяют текст НПА.' })}<div class="laws">${D.laws.filter(l => l.type === type).map(l => `<article class="law-card"><p class="eyebrow">${l.number}</p><h2>${l.title}</h2><p>${l.scope}</p><div class="law-rule"><span>В работе педагога</span><p>${l.rule}</p></div><details><summary>Что сверить в документе</summary><p>${l.articles}</p></details><a class="text-link" href="${l.url}" target="_blank" rel="noopener noreferrer">Открыть в «Әділет» <span aria-hidden="true">↗</span><span class="visually-hidden"> (новая вкладка)</span></a><p class="source-status">${l.status}</p></article>`).join('')}</div>`;
  }
  function templates() {
    const empty = {};
    return `<div class="notice"><div><h3>Шаблон нужно адаптировать</h3><p>Замените квадратные скобки фактическими данными. «Учебные задания» — дополнительная адаптация общей формулы руководства; остальные сценарии основаны на его готовых шаблонах.</p></div></div><div class="template-list">${D.tasks.map(t => `<details class="template-item"><summary><span><strong>${t.title}</strong><small>${t.short}</small></span><span aria-hidden="true">+</span></summary><div class="template-content">${promptBlock(PromptEngine.generatePrompt(empty, t))}${buttonLink('Заполнить в конструкторе', `#/create/builder/${t.id}`)}</div></details>`).join('')}</div><h2>Универсальная основа</h2>${promptBlock('Подготовь [вид результата] для [класс и аудитория].\nЦель обучения: [точная формулировка и код из программы].\nКонтекст: [предмет, тема, язык, время, уровень, ресурсы, формат работы].\nИсходные материалы: [файлы и назначение каждого]. Используй только [разрешённые источники].\nТребования: [состав, последовательность, сложность, дифференциация, оценивание].\nФормат: [разделы, объём, язык].\nОграничения: [данные, авторское право, безопасность, что не добавлять].\nПроверка: сопоставь результат с целью, отметь непроверенные факты и решения для педагога.\nЕсли данных недостаточно, задай не более трёх уточняющих вопросов.')}<h2>Шаблон на казахском языке</h2><p>Сохранён из руководства для формативной обратной связи.</p><div lang="kk">${promptBlock('Иесіздендірілген оқушы жұмысына қысқа әрі құрметті кері байланыс құрастыр.\n[Критерий] бағалау критерийіне және жұмыстағы нақты дәлелге сүйен.\nБір дәлелденген күшті тұсты, жақсартудың бір басымдығын, түсінікті келесі қадамды және өзіндік тексеруге арналған бір сұрақты енгіз.\nОқушыға тікелей үн қат. Оны басқа оқушылармен салыстырма және қабілеті немесе мінезі туралы қорытынды жасама.\nКөлемі 100 сөзден аспасын. Дерек жеткіліксіз болса, қандай дәлел қажет екенін көрсет.')}</div>`;
  }
  function literature() {
    return `<section class="source-primary"><span class="eyebrow">ОСНОВНОЙ ИСТОЧНИК</span><h2>Методическое руководство по созданию промтов</h2><p>Bilim Group, Республика Казахстан, 2026. Сайт адаптирует содержание предоставленного документа: сокращает повторы, сохраняет формулу, алгоритмы, шаблоны, проверку, безопасность, НПА и литературу.</p><p>Визуальная основа — предоставленная презентация «ChatGPT Edu для школ TechOrda». Логотипы Bilim Group и Bilim UpSkill извлечены из PDF; их права сохраняются за правообладателями.</p></section><h2>Исследования и методические материалы</h2><p>Библиографические сведения и ссылки перенесены из руководства.</p><div class="literature-list">${D.literature.map((x, i) => `<article><span class="literature-number">0${i + 1}</span><div><h3>${x[0]}</h3><p>${x[1]}</p><p class="muted">${x[3]}</p><a class="text-link" href="${x[2]}" target="_blank" rel="noopener noreferrer">Открыть источник ↗<span class="visually-hidden"> (новая вкладка)</span></a></div></article>`).join('')}</div>${buttonLink('Нормативные источники', '#/npa/sources')}`;
  }
  function render(focus = true) {
    copies = [];
    const path = location.hash.replace(/^#\/?/, '').split('/').filter(Boolean);
    if (!path.length || location.hash === '#main') {
      navigation(''); $('#main').innerHTML = home(); document.title = 'Промпты для учителя · Bilim UpSkill';
    } else {
      const section = D.sections.find(s => s.id === path[0]);
      const page = path[1] || section?.pages[0][0];
      if (!section || !section.pages.some(p => p[0] === page)) {
        navigation(''); $('#main').innerHTML = `<div class="container not-found"><p class="eyebrow">СТРАНИЦА НЕ НАЙДЕНА</p><h1>Вернёмся к вашей задаче</h1>${buttonLink('На главную', '#/')}</div>`;
        document.title = 'Страница не найдена · Bilim UpSkill';
      } else {
        navigation(section.id);
        const key = `${section.id}/${page}`;
        let title, lead, body;
        if (key === 'create/builder') {
          if (D.tasks.some(t => t.id === path[2]) && state.task !== path[2]) { state.task = path[2]; state.dirty = !!state.result; }
          title = 'Конструктор промпта'; lead = 'Ваши условия + проверенный шаблон = запрос, с которым удобно работать.'; body = builder();
        } else if (key === 'create/scenarios') {
          title = 'Шесть задач для педагогической практики'; lead = 'Выберите нужный результат. Конструктор подставит структуру и требования этого сценария.'; body = tasks() + `<div class="scenario-details">${D.tasks.map(t => `<article class="content-card"><h2>${t.title}</h2><p>${t.requirements}</p><a class="text-link" href="#/create/builder/${t.id}">Создать промпт ↗</a></article>`).join('')}</div>`;
        } else if (key === 'check/checklist') {
          title = 'Проверьте результат перед уроком'; lead = 'Самопроверка ИИ полезна, но не заменяет независимую проверку педагога.'; body = checklist();
        } else if (key === 'npa/laws' || key === 'npa/orders') {
          title = page === 'laws' ? 'Законы Республики Казахстан' : 'Приказы для педагогической работы'; lead = 'Официальные источники и практические ориентиры из методического руководства.'; body = laws(page === 'laws' ? 'law' : 'order');
        } else if (key === 'library/templates') { title = 'Готовые шаблоны промптов'; lead = 'Возьмите основу, заполните своими данными и проверьте результат.'; body = templates();
        } else if (key === 'library/terms') { title = 'Термины простыми словами'; lead = 'Рабочие определения для использования руководства. Юридические формулировки сверяйте в НПА.'; body = `<dl class="glossary">${D.terms.map(x => `<div><dt>${x[0]}</dt><dd>${x[1]}</dd></div>`).join('')}</dl>`;
        } else if (key === 'library/principles') { title = 'Педагогический замысел важнее формулы'; lead = 'Десять принципов, которые помогают сформулировать запрос и оценить ответ.'; body = cards(D.principles);
        } else if (key === 'library/literature') { title = 'Источники и литература'; lead = 'На чём основаны содержание и визуальное оформление сайта.'; body = literature();
        } else { const p = D.pages[key]; title = p.title; lead = p.lead; body = p.blocks.map(renderBlock).join(''); }
        $('#main').innerHTML = layout(section, page, body, title, lead);
        if (key === 'create/builder') $('#main').classList.add('builder-page'); else $('#main').classList.remove('builder-page');
        document.title = `${title} · Bilim UpSkill`;
      }
    }
    $('#navigation').classList.remove('mobile-open'); $('.menu-toggle').setAttribute('aria-expanded', 'false');
    if (focus) { $('#main').focus({ preventScroll: true }); window.scrollTo({ top: 0, behavior: 'instant' }); }
    wireContent();
  }
  function notify(text) { $('#notification').textContent = text; $('#notification').classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => $('#notification').classList.remove('show'), 4500); }
  async function copy(text) {
    try {
      if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(text);
      else {
        const area = document.createElement('textarea'); area.value = text; area.style.cssText = 'position:fixed;left:-9999px;'; document.body.append(area); area.select();
        const ok = document.execCommand('copy'); area.remove(); if (!ok) throw new Error('Clipboard unavailable');
      }
      notify('Промпт скопирован');
    } catch { notify('Не удалось скопировать автоматически. Выделите текст и нажмите Ctrl+C или используйте меню копирования.'); $('#prompt-result')?.focus(); $('#prompt-result')?.select(); }
  }
  function wireContent() {
    document.querySelectorAll('[data-copy]').forEach(b => b.addEventListener('click', () => copy(copies[Number(b.dataset.copy)])));
    document.querySelectorAll('[data-task]').forEach(b => b.addEventListener('click', () => {
      state.task = b.dataset.task; state.dirty = !!state.result;
      history.replaceState(null, '', `#/create/builder/${state.task}`); render(false); $(`[data-task="${state.task}"]`).focus();
    }));
    const form = $('#prompt-form');
    if (form) {
      form.addEventListener('input', e => {
        if (e.target.name) state.fields[e.target.name] = e.target.value;
        if (state.result) { state.dirty = true; $('#copy-result').disabled = true; $('#result-status').textContent = 'Поля изменены. Соберите промпт заново.'; $('#result-title').textContent = 'Обновите промпт'; }
      });
      form.addEventListener('submit', e => {
        e.preventDefault();
        // Native validation covers required fields; also reject whitespace-only text.
        for (const input of form.querySelectorAll('[required]')) {
          input.setCustomValidity(input.value.trim() ? '' : 'Заполните это поле.');
          if (!input.reportValidity()) { input.addEventListener('input', () => input.setCustomValidity(''), { once: true }); return; }
        }
        state.fields = Object.fromEntries(new FormData(form));
        state.result = PromptEngine.generatePrompt(state.fields, D.tasks.find(t => t.id === state.task)); state.dirty = false;
        $('#empty-result').hidden = true; $('#prompt-result').hidden = false; $('#prompt-result').value = state.result;
        $('#copy-result').disabled = false; $('#result-title').textContent = 'Ваш промпт готов';
        $('#result-status').textContent = 'Скопируйте текст в разрешённый ИИ-сервис и приложите указанные источники.';
        notify('Промпт готов. Перед отправкой проверьте данные.');
        if (matchMedia('(max-width: 1050px)').matches) $('.result-panel').scrollIntoView({ behavior: 'smooth', block: 'start' });
        $('#prompt-result').focus({ preventScroll: true });
      });
      $('#copy-result').addEventListener('click', () => { if (!state.dirty && state.result) copy(state.result); });
    }
    document.querySelectorAll('[data-check]').forEach(c => c.addEventListener('change', () => {
      const i = Number(c.dataset.check); c.checked ? state.checks.add(i) : state.checks.delete(i); updateChecks();
    }));
    $('#reset-checks')?.addEventListener('click', () => { state.checks.clear(); document.querySelectorAll('[data-check]').forEach(c => c.checked = false); updateChecks(); });
  }
  function updateChecks() { $('#check-count').textContent = `${state.checks.size} из ${D.checklist.length} проверено`; $('#check-progress').value = state.checks.size; $('#check-conclusion').textContent = checkConclusion(); }
  $('.menu-toggle').addEventListener('click', () => { const open = $('#navigation').classList.toggle('mobile-open'); $('.menu-toggle').setAttribute('aria-expanded', String(open)); });
  $('#navigation').addEventListener('click', e => {
    if (e.target.closest('a')) { $('#navigation').classList.remove('mobile-open'); $('.menu-toggle').setAttribute('aria-expanded', 'false'); }
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      if ($('#navigation').classList.contains('mobile-open')) { $('#navigation').classList.remove('mobile-open'); $('.menu-toggle').setAttribute('aria-expanded', 'false'); $('.menu-toggle').focus(); }
    }
  });
  $('.skip-link').addEventListener('click', e => { e.preventDefault(); $('#main').focus(); });
  window.addEventListener('hashchange', () => render());
  render(false);
})();
