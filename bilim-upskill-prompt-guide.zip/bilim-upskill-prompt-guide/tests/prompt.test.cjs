const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const { generatePrompt } = require('../src/prompt.js');
const sandbox = { window: {} };
vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../src/data.js'), 'utf8'), sandbox);
const D = sandbox.window.GUIDE;
const input = { subject: 'Информатика', grade: '7', topic: 'Условный оператор', objective: 'Тест: точная формулировка «если — иначе» без изменений.', time: '25', context: 'Работа в парах', sources: 'Программа; работа А; критерии', requirements: 'Одна дополнительная опора', format: 'Короткие инструкции', constraints: 'Без сети', verification: 'Проверить граничные случаи' };

test('all six scenarios preserve exact input and enforce independent teacher verification', () => {
  assert.equal(D.tasks.length, 6);
  const results = D.tasks.map(t => {
    const result = generatePrompt(input, t);
    for (const v of Object.values(input)) assert.ok(result.includes(v), `Missing input: ${v}`);
    assert.ok(result.includes('Окончательное решение'));
    assert.ok(result.includes('Не придумывай'));
    assert.ok(result.includes('не более трёх'));
    assert.ok(result.includes('не заменяет независимую проверку'));
    return result;
  });
  assert.equal(new Set(results).size, 6);
});
test('review stops scoring unreadable parts and requires evidence', () => {
  const result = generatePrompt(input, D.tasks.find(t => t.id === 'review'));
  assert.match(result, /останови оценивание соответствующей части/);
  assert.match(result, /свидетельство из работы/);
  assert.match(result, /если он предусмотрен схемой/);
});
test('worksheet separates answers; feedback is respectful and bounded', () => {
  assert.match(generatePrompt(input, D.tasks.find(t => t.id === 'worksheet')), /В ученической части нет ответов/);
  const feedback = generatePrompt(input, D.tasks.find(t => t.id === 'feedback'));
  assert.match(feedback, /Не более 100 слов/);
  assert.match(feedback, /Не сравнивай/);
});
test('empty template names missing data explicitly without inventing objectives', () => {
  const result = generatePrompt({}, D.tasks[0]);
  assert.match(result, /\[код и точная формулировка из действующей программы\]/);
  assert.ok(!result.includes('undefined'));
  assert.ok(!result.includes('null'));
});
test('all navigation destinations have content and every law uses an official source', () => {
  const generated = new Set(['create/builder', 'create/scenarios', 'check/checklist', 'npa/laws', 'npa/orders', 'library/templates', 'library/terms', 'library/principles', 'library/literature']);
  for (const section of D.sections) for (const [id] of section.pages) assert.ok(generated.has(`${section.id}/${id}`) || D.pages[`${section.id}/${id}`]);
  assert.equal(D.elements.length, 8); assert.equal(D.laws.length, 8); assert.equal(D.checklist.length, 9);
  for (const law of D.laws) assert.match(law.url, /^https:\/\/(old\.)?adilet\.zan\.kz\/rus\/docs\//);
});
